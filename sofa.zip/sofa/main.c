#include <stdio.h>
#include "sum.h"
#include "sub.h"

int main() {
    int x = 5, y = 6;

    int s = sum(x, y);
    int d = sub(x, y);

    printf("Сумма: %d\n", s);
    printf("Разность: %d\n", d);
    printf("c=%d, d=%d\n", s, d);

    return 0;
}
